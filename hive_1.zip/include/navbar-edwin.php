  <div class="navbar w-nav" data-animation="over-left" data-collapse="all" data-duration="400">
    <div class="w-container">
      <a class="navbarlogo w-nav-brand" href="<?= base_url() ?>"><img src="<?= base_url() ?>/resources/images/EdwonLogo_4.png" width="87">
      </a>
      <nav class="openmenu w-nav-menu" role="navigation">
        <a class="btnclose w-inline-block" data-ix="new-interaction" href="#"></a>
        <h1 class="edwinmenu">Edwin<br>Prasetyo</h1><img class="reddivbar" src="<?= base_url() ?>/resources/images/barmerah-33.png"><a class="navlink w-nav-link" href="<?= base_url() ?>">Home</a><a class="navlink w-nav-link" href="<?=base_url()?>about">About</a><a class="navlink w-nav-link" href="#">Videos</a><a class="navlink w-nav-link" href="<?=base_url()?>blog">Blog</a><a class="navlink w-nav-link" href="<?=base_url()?>contact">Contact</a>
      </nav>
      <div class="menubtn w-nav-button">
        <div class="iconstyle w-icon-nav-menu"></div>
      </div>
    </div>
  </div>