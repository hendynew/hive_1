

        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="<?=base_url()?>">
                                Visit Your Page
                            </a>
                        </li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; 2017 <a href="#">Hive CP</a>
                </p>
            </div>
        </footer>

    </div>
</div>
